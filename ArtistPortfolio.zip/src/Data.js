
const Data = {
  WebsiteTitle: "EVexe",
  HeaderTitle: "Portfolio Title",
  FooterText: "Little Foot",
  AboutEmail: "evve.vt@gmail.com",
  AboutEmailSubject: "Email Subject",
  AboutHeading: "Sobre Mi",
  AboutTextParagraph1: "El texto del About Page xd",
  AboutTextParagraph2: "El segundo parrafo
(El regreso del About Page)",
  AboutButtonText: "Aboutxd",
};

export default Data;
